#!/usr/bin/env lua5.3
local TD1function = {}
local TD2function = {}
local TD3function = {}
local TD4function = {}
local TD = {
TdUpdate = true,
config = {}
}
local TDLib =  require('tdlua') 
local client = TDLib()
local https = require("ssl.https")
local http = require("socket.http")
----------------------------------------------
function Telesend(method,database,yok)
local function a(b)
return string.format("%%%02X",string.byte(b))
end
function c(b)
local b=string.gsub(b,"\\","\\")
local b=string.gsub(b,"([^%w])",a)
return b
end
local function d(e)
local f=""
for g,h in pairs(e) do 
if type(h)=='table'then 
for i,j in ipairs(h) do 
f=f..string.format("%s[]=%s&",g,c(j))
end
else f=f..string.format("%s=%s&",g,c(h))
end
end
local f=string.reverse(string.gsub(string.reverse(f),"&","",1))
return f 
end 
if database.message_id then
database.message_id = (database.message_id/2097152/0.5)
end
if database.reply_to_message_id then
database.reply_to_message_id = (database.reply_to_message_id/2097152/0.5)
end 
local url , res = https.request("https://api.telegram.org/bot"..(yok).."/"..method.."?"..d(database))
return res 
end
function TD2function.sendcall(update)
if update and type(update) == 'table' then
for i = 0 , #TD3function do
if not TD3function[i].filters then
send_update = true
update_message = update
elseif update.TD and TD3function[i].filters and TD1function.in_array(TD3function[i].filters,  update.TD) then
send_update = true
update_message = update
else
send_update = false
end
if update_message and send_update and type(update_message) == 'table' then
xpcall(TD3function[i].def, TD2function.print_error, update_message)
end
update_message = nil
send_update = nil
end
end
end
function TD2function.change_table(input, send)
if send then
changes ={
TD = string.reverse('epyt@')
}
rems = {
}
  else
changes = {
_ = string.reverse('DT'),
}
rems = {
string.reverse('epyt@')
}
end
if type(input) == 'table' then
local res = {}
for key,value in pairs(input) do
for k, rem in pairs(rems) do
if key == rem then
value = nil
end
end
local key = changes[key] or key
if type(value) ~= 'table' then
res[key] = value
else
res[key] = TD2function.change_table(value, send)
end
end
return res
else
return input
end
end
function TD2function.run_table(input)
local to_original = TD2function.change_table(input, true)
local result = client:execute(to_original)
if type(result) ~= 'table' then
return nil
else
return TD2function.change_table(result)
end
end
function TD2function.print_error(err)
  print('There is an error in the file, please correct it '.. err)
end
function TD2function.send_tdlib(input)
local to_original = TD2function.change_table(input, true)
client:send(to_original)
end
TD2function.send_tdlib{
TD = 'getAuthorizationState'
}
TDLib.setLogLevel(3)
TDLib.setLogPath('/usr/lib/x86_64-linux-gnu/lua/5.3/.TD.log')
-----------------------------------------------TD1function
function TD1function.len(input)
if type(input) == 'table' then
size = 0
for key,value in pairs(input) do
size = size + 1
end
return size
  else
size = tostring(input)
return #size
end
end
function TD1function.match(...)
local val = {}
  for no,v in ipairs({...}) do
val[v] = true
end
return val
end
function TD1function.secToClock(seconds)
local seconds = tonumber(seconds)
if seconds <= 0 then
return {hours=00,mins=00,secs=00}
  else
local hours = string.format("%02.f", math.floor(seconds / 3600));
local mins = string.format("%02.f", math.floor(seconds / 60 - ( hours*60 ) ));
local secs = string.format("%02.f", math.floor(seconds - hours * 3600 - mins * 60));
return {hours=hours,mins=mins,secs=secs}
end
end
function TD1function.number_format(num)
local out = tonumber(num)
  while true do
out,i= string.gsub(out,'^(-?%d+)(%d%d%d)', '%1,%2')
if (i==0) then
break
end
end
return out
end
function TD1function.base64_encode(str)
	local Base ='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
	return ((str:gsub('.', function(x)
			local r,Base='',x:byte()
			for i=8,1,-1 do r=r..(Base%2^i-Base%2^(i-1)>0 and '1' or '0') end
			return r;
	end)..'0000'):gsub('%d%d%d?%d?%d?%d?', function(x)
			if (#x < 6) then return '' end
			local c=0
			for i=1,6 do c=c+(x:sub(i,i)=='1' and 2^(6-i) or 0) end
			return Base:sub(c+1,c+1)
	end)..({ '', '==', '=' })[#str%3+1])
end
function TD1function.base64_decode(str)
	local Base ='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
  str = string.gsub(str, '[^'..Base..'=]', '')
return (str:gsub('.', function(x)
if (x == '=') then
return ''
end
local r,f='',(Base:find(x)-1)
for i=6,1,-1 do r=r..(f%2^i-f%2^(i-1)>0 and '1' or '0') end
return r;
end):gsub('%d%d%d?%d?%d?%d?%d?%d?', function(x)
if (#x ~= 8) then
return ''
end
local c=0
for i=1,8 do c=c+(x:sub(i,i)=='1' and 2^(8-i) or 0) end
return string.char(c)
end))
end
function TD1function.exists(file)
 local ok, err, code = os.rename(file, file)
 if not ok then
if code == 13 then
 return true
end
 end
 return ok, err
end
function TD1function.in_array(table, value)
  for k,v in pairs(table) do
if value == v then
return true
end
end
return false
end
function TD1function.add_events(def,filters)
if type(def) ~= 'function' then
TD2function.print_error('the add_events def must be a function !')
return {
TD = false,
}
  elseif type(filters) ~= 'table' then
TD2function.print_error('the add_events filters must be a table !')
return {
TD = false,
}
else
local function_id = #TD3function + 1
TD3function[function_id] = {}
TD3function[function_id].def = def
TD3function[function_id].filters = filters
return {
TD = true,
}
end
end


function TD1function.set_timer(seconds, def, argv)
if type(seconds) ~= 'number' then
return {
TD = false,
message = 'set_timer(int seconds, funtion def, table)'
}
elseif type(def) ~= 'function' then
return {
TD = false,
message = 'set_timer(int seconds, funtion def, table)'
}
end
TD4function[#TD4function + 1] = {
def = def,
argv = argv,
run_in = os.time() + seconds
}
return {
TD = true,
run_in = os.time() + seconds,
timer_id = #TD4function
}
end
function TD1function.get_timer(timer_id)
local timer_data = TD4function[timer_id]
if timer_data then
return {
TD = true,
run_in = timer_data.run_in,
argv = timer_data.argv
}
  else
return {
TD = false,
}
end
end
function TD1function.cancel_timer(timer_id)
if TD4function[timer_id] then
table.remove(TD4function,timer_id)
return {
TD = true
}
  else
return {
TD = false
}
end
end
function TD1function.replyMarkup(input)
if type(input.type) ~= 'string' then
return nil
end
local _type = string.lower(input.type)
if _type == 'inline' then
local result = {
TD = 'replyMarkupInlineKeyboard',
rows = {
}
}
for _, rows in pairs(input.data) do
local new_id = #result.rows + 1
result.rows[new_id] = {}
for key, value in pairs(rows) do
  local rows_new_id = #result.rows[new_id] + 1
if value.url and value.text then
result.rows[new_id][rows_new_id] = {
  TD = 'inlineKeyboardButton',
text = value.text,
type = {
TD = 'inlineKeyboardButtonTypeUrl',
  url = value.url
}
}
elseif value.data and value.text then
result.rows[new_id][rows_new_id] = {
TD = 'inlineKeyboardButton',
  text = value.text,
  type = {
data = TD1function.base64_encode(value.data), -- Base64 only
TD = 'inlineKeyboardButtonTypeCallback',
}
}
  elseif value.forward_text and value.id and value.url and value.text then
result.rows[new_id][rows_new_id] = {
TD = 'inlineKeyboardButton',
  text = value.text,
  type = {
id = value.id,
url = value.url,
forward_text = value.forward_text,
TD = 'inlineKeyboardButtonTypeLoginUrl',
}
}
  elseif value.query and value.text then
result.rows[new_id][rows_new_id] = {
TD = 'inlineKeyboardButton',
  text = value.text,
  type = {
query = value.query,
TD = 'inlineKeyboardButtonTypeSwitchInline',
}
}
end
end
end
return result
elseif _type == 'keyboard' then
local result = {
TD = 'replyMarkupShowKeyboard',
resize_keyboard = input.resize,
one_time = input.one_time,
is_personal = input.is_personal,
rows = {
}
}
for _, rows in pairs(input.data) do
local new_id = #result.rows + 1
result.rows[new_id] = {}
for key, value in pairs(rows) do
  local rows_new_id = #result.rows[new_id] + 1
if type(value.type) == 'string' then
value.type = string.lower(value.type)
if value.type == 'requestlocation' and value.text then
result.rows[new_id][rows_new_id] = {
  type = {
TD = 'keyboardButtonTypeRequestLocation'
},
TD = 'keyboardButton',
  text = value.text
}
  elseif value.type == 'requestphone' and value.text then
result.rows[new_id][rows_new_id] = {
  type = {
TD = 'keyboardButtonTypeRequestPhoneNumber'
},
TD = 'keyboardButton',
  text = value.text
}
  elseif value.type == 'requestpoll' and value.text then
result.rows[new_id][rows_new_id] = {
  type = {
TD = 'keyboardButtonTypeRequestPoll',
force_regular = value.force_regular,
force_quiz = value.force_quiz
},
TD = 'keyboardButton',
  text = value.text
}
  elseif value.type == 'text' and value.text then
result.rows[new_id][rows_new_id] = {
  type = {
TD = 'keyboardButtonTypeText'
},
TD = 'keyboardButton',
  text = value.text
}
end
end
end
end
return result
elseif _type == 'forcereply' then
return {
TD = 'replyMarkupForceReply',
is_personal = input.is_personal
}
elseif _type == 'remove' then
return {
TD = 'replyMarkupRemoveKeyboard',
is_personal = input.is_personal
}
end
end
function TD1function.addProxy(proxy_type, server, port, username, password_secret, http_only)
if type(proxy_type) ~= 'string' then
return {
TD = false
}
end
local proxy_type = string.lower(proxy_type)
if proxy_type == 'mtproto' then
_type_ = {
TD = 'proxyTypeMtproto',
secret = password_secret
}
elseif proxy_Type == 'socks5' then
_type_ = {
TD = 'proxyTypeSocks5',
username = username,
password = password_secret
}
elseif proxy_Type == 'http' then
_type_ = {
TD = 'proxyTypeHttp',
username = username,
password = password_secret,
http_only = http_only
}
  else
return {
TD = false
}
end
return TD2function.run_table{
TD = 'addProxy',
server = server,
port = port,
type = _type_
}
end
function TD1function.enableProxy(proxy_id)
return TD2function.run_table{
 TD = 'enableProxy',
proxy_id = proxy_id
}
end
function TD1function.pingProxy(proxy_id)
return TD2function.run_table{
 TD = 'pingProxy',
proxy_id = proxy_id
}
end
function TD1function.disableProxy(proxy_id)
return TD2function.run_table{
 TD = 'disableProxy',
proxy_id = proxy_id
}
end
function TD1function.getProxies()
return TD2function.run_table{
TD = 'getProxies'
}
end
function TD1function.getChatId(chat_id)
local chat_id = tostring(chat_id)
if chat_id:match('^-100') then
return {
id = string.sub(chat_id, 5),
type = 'supergroup'
}
  else
local basicgroup_id = string.sub(chat_id, 2)
return {
id = string.sub(chat_id, 2),
type = 'basicgroup'
}
end
end
function TD1function.getInputFile(file, conversion_str, expected_size)
local str = tostring(file)
if (conversion_str and expectedsize) then
return {
TD = 'inputFileGenerated',
original_path = tostring(file),
conversion = tostring(conversion_str),
expected_size = expected_size
}
else
if str:match('/') then
return {
TD = 'inputFileLocal',
  path = file
}
  elseif str:match('^%d+$') then
return {
TD = 'inputFileId',
  id = file
}
else
return {
TD = 'inputFileRemote',
  id = file
}
end
end
end
function TD1function.getParseMode(parse_mode)
if parse_mode then
local mode = parse_mode:lower()
if mode == 'markdown' or mode == 'md' then
return {
TD = 'textParseModeMarkdown'
}
elseif mode == 'html' or mode == 'lg' then
return {
TD = 'textParseModeHTML'
}
end
end
end
function TD1function.parseTextEntities(text, parse_mode)
if type(parse_mode) == 'string' and string.lower(parse_mode) == 'lg' then
for txt in text:gmatch('%%{(.-)}') do
local _text, text_type = txt:match('(.*),(.*)')
local txt = string.gsub(txt,'+','++')
local text_type = string.gsub(text_type,' ','')
if type(_text) == 'string' and type(text_type) == 'string' then
  for key, value in pairs({['<'] = '&lt;',['>'] = '&gt;'}) do
_text = string.gsub(_text, key, value)
end
if (string.lower(text_type) == 'b' or string.lower(text_type) == 'i' or string.lower(text_type) == 'c') then
local text_type = string.lower(text_type)
local text_type = text_type == 'c' and 'code' or text_type
text = string.gsub(text,'%%{'..txt..'}','<'..text_type..'>'.._text..'</'..text_type..'>')
  else
if type(tonumber(text_type)) == 'number' then
link = 'tg://user?id='..text_type
else
link = text_type
end
text = string.gsub(text, '%%{'..txt..'}', '<a href="'..link..'">'.._text..'</a>')
end
end
end
end
return TD2function.run_table{
TD = 'parseTextEntities',
text = tostring(text),
parse_mode = TD1function.getParseMode(parse_mode)
}
end
function TD1function.vectorize(table)
if type(table) == 'table' then
return table
  else
return {
table
}
end
end
function TD1function.setLimit(limit, num)
local limit = tonumber(limit)
local number = tonumber(num or limit)
return (number >= limit) and limit or number
end
function TD1function.sendMessage(chat_id, reply_to_message_id, input_message_content, parse_mode, disable_notification, from_background, reply_markup)
local TD_body, message = {
TD = 'sendMessage',
chat_id = chat_id,
reply_to_message_id = reply_to_message_id or 0,
disable_notification = disable_notification or 0,
from_background = from_background or 1,
reply_markup = reply_markup,
input_message_content = input_message_content
}, {}
if input_message_content.text then
text = input_message_content.text.text
elseif input_message_content.caption then
text = input_message_content.caption.text
end
if text then
if parse_mode then
local result = TD1function.parseTextEntities(text, parse_mode)
if TD_body.input_message_content.text then
TD_body.input_message_content.text = result
else
TD_body.input_message_content.caption = result
end
return TD2function.run_table(TD_body)
else
while #text > 4096 do
  text = string.sub(text, 4096, #text)
  message[#message + 1] = text
end
message[#message + 1] = text
for i = 1, #message do
if input_message_content.text and input_message_content.text.text then
TD_body.input_message_content.text.text = message[i]
elseif input_message_content.caption and input_message_content.caption.text then
TD_body.input_message_content.caption.text = message[i]
end
return TD2function.run_table(TD_body)
end
end
  else
return TD2function.run_table(TD_body)
end
end
function TD1function.logOut()
return TD2function.run_table{
TD = 'logOut'
}
end
function TD1function.getPasswordState()
return TD2function.run_table{
TD = 'getPasswordState'
}
end
function TD1function.setPassword(old_password, new_password, new_hint, set_recovery_email_address, new_recovery_email_address)
return TD2function.run_table{
old_password = tostring(old_password),
new_password = tostring(new_password),
new_hint = tostring(new_hint),
set_recovery_email_address = set_recovery_email_address,
new_recovery_email_address = tostring(new_recovery_email_address)
}
end
function TD1function.getRecoveryEmailAddress(password)
return TD2function.run_table{
TD = 'getRecoveryEmailAddress',
password = tostring(password)
}
end
function TD1function.setRecoveryEmailAddress(password, new_recovery_email_address)
return TD2function.run_table{
TD = 'setRecoveryEmailAddress',
password = tostring(password),
new_recovery_email_address = tostring(new_recovery_email_address)
}
end
function TD1function.requestPasswordRecovery()
return TD2function.run_table{
TD = 'requestPasswordRecovery'
}
end
function TD1function.recoverPassword(recovery_code)
return TD2function.run_table{
TD = 'recoverPassword',
recovery_code = tostring(recovery_code)
}
end
function TD1function.createTemporaryPassword(password, valid_for)
local valid_for = valid_for > 86400 and 86400 or valid_for
return TD2function.run_table{
TD = 'createTemporaryPassword',
password = tostring(password),
valid_for = valid_for
}
end
function TD1function.getTemporaryPasswordState()
return TD2function.run_table{
TD = 'getTemporaryPasswordState'
}
end
function TD1function.getMe()
return TD2function.run_table{
TD = 'getMe'
}
end
function TD1function.getUser(user_id)
return TD2function.run_table{
TD = 'getUser',
user_id = user_id
}
end
function TD1function.getUserFullInfo(user_id)
return TD2function.run_table{
TD = 'getUserFullInfo',
user_id = user_id
}
end
function TD1function.getBasicGroup(basic_group_id)
return TD2function.run_table{
TD = 'getBasicGroup',
basic_group_id = TD1function.getChatId(basic_group_id).id
}
end
function TD1function.getBasicGroupFullInfo(basic_group_id)
return TD2function.run_table{
TD = 'getBasicGroupFullInfo',
basic_group_id = TD1function.getChatId(basic_group_id).id
}
end
function TD1function.getSupergroup(supergroup_id)
return TD2function.run_table{
TD = 'getSupergroup',
supergroup_id = TD1function.getChatId(supergroup_id).id
}
end
function TD1function.getSupergroupFullInfo(supergroup_id)
return TD2function.run_table{
TD = 'getSupergroupFullInfo',
supergroup_id = TD1function.getChatId(supergroup_id).id
}
end
function TD1function.getSecretChat(secret_chat_id)
return TD2function.run_table{
TD = 'getSecretChat',
secret_chat_id = secret_chat_id
}
end
function TD1function.getChat(chat_id)
return TD2function.run_table{
TD = 'getChat',
chat_id = chat_id
}
end
function TD1function.getMessage(chat_id, message_id)
return TD2function.run_table{
TD = 'getMessage',
chat_id = chat_id,
message_id = message_id
}
end
function TD1function.getRepliedMessage(chat_id, message_id)
return TD2function.run_table{
TD = 'getRepliedMessage',
chat_id = chat_id,
message_id = message_id
}
end
function TD1function.getChatPinnedMessage(chat_id)
return TD2function.run_table{
TD = 'getChatPinnedMessage',
chat_id = chat_id
}
end
function TD1function.unpinAllChatMessages(chat_id)
return TD2function.run_table{
TD = 'unpinAllChatMessages',
chat_id = chat_id
}
end
function TD1function.getMessages(chat_id, message_ids)
return TD2function.run_table{
TD = 'getMessages',
chat_id = chat_id,
message_ids = TD1function.vectorize(message_ids)
}
end
function TD1function.getFile(file_id)
return TD2function.run_table{
TD = 'getFile',
file_id = file_id
}
end
function TD1function.getRemoteFile(remote_file_id, file_type)
return TD2function.run_table{
TD = 'getRemoteFile',
remote_file_id = tostring(remote_file_id),
file_type = {
TD = 'fileType' .. file_type or 'Unknown'
}
}
end
function TD1function.getChats(chat_list, offset_order, offset_chat_id, limit)
local limit = limit or 20
local offset_order = offset_order or '9223372036854775807'
local offset_chat_id = offset_chat_id or 0
local filter = (string.lower(tostring(chat_list)) == 'archive') and 'chatListArchive' or 'chatListMain'
return TD2function.run_table{
TD = 'getChats',
offset_order = offset_order,
offset_chat_id = offset_chat_id,
limit = TD1function.setLimit(100, limit),
chat_list = {
TD = filter
}
}
end
function TD1function.searchPublicChat(username)
return TD2function.run_table{
TD = 'searchPublicChat',
username = tostring(username)
}
end
function TD1function.searchPublicChats(query)
return TD2function.run_table{
TD = 'searchPublicChats',
query = tostring(query)
}
end
function TD1function.searchChats(query, limit)
return TD2function.run_table{
TD = 'searchChats',
query = tostring(query),
limit = limit
}
end
function TD1function.checkChatUsername(chat_id, username)
return TD2function.run_table{
TD = 'checkChatUsername',
chat_id = chat_id,
username = tostring(username)
}
end
function TD1function.searchChatsOnServer(query, limit)
return TD2function.run_table{
TD = 'searchChatsOnServer',
query = tostring(query),
limit = limit
}
end
function TD1function.clearRecentlyFoundChats()
return TD2function.run_table{
TD = 'clearRecentlyFoundChats'
}
end
function TD1function.getTopChats(category, limit)
return TD2function.run_table{
TD = 'getTopChats',
category = {
TD = 'topChatCategory' .. category
},
limit = TD1function.setLimit(30, limit)
}
end
function TD1function.removeTopChat(category, chat_id)
return TD2function.run_table{
TD = 'removeTopChat',
category = {
TD = 'topChatCategory' .. category
},
chat_id = chat_id
}
end
function TD1function.addRecentlyFoundChat(chat_id)
return TD2function.run_table{
TD = 'addRecentlyFoundChat',
chat_id = chat_id
}
end
function TD1function.getCreatedPublicChats()
return TD2function.run_table{
TD = 'getCreatedPublicChats'
}
end
function TD1function.removeRecentlyFoundChat(chat_id)
return TD2function.run_table{
TD = 'removeRecentlyFoundChat',
chat_id = chat_id
}
end
function TD1function.getChatHistory(chat_id, from_message_id, offset, limit, only_local)
return TD2function.run_table{
TD = 'getChatHistory',
chat_id = chat_id,
from_message_id = from_message_id,
offset = offset,
limit = TD1function.setLimit(100, limit),
only_local = only_local
}
end
function TD1function.getGroupsInCommon(user_id, offset_chat_id, limit)
return TD2function.run_table{
TD = 'getGroupsInCommon',
user_id = user_id,
offset_chat_id = offset_chat_id or 0,
limit = TD1function.setLimit(100, limit)
}
end
function TD1function.searchMessages(query, offset_date, offset_chat_id, offset_message_id, limit)
return TD2function.run_table{
TD = 'searchMessages',
query = tostring(query),
offset_date = offset_date or 0,
offset_chat_id = offset_chat_id or 0,
offset_message_id = offset_message_id or 0,
limit = TD1function.setLimit(100, limit)
}
end
function TD1function.searchChatMessages(chat_id, query, filter, sender_user_id, from_message_id, offset, limit)
return TD2function.run_table{
TD = 'searchChatMessages',
chat_id = chat_id,
query = tostring(query),
sender_user_id = sender_user_id or 0,
from_message_id = from_message_id or 0,
offset = offset or 0,
limit = TD1function.setLimit(100, limit),
filter = {
TD = 'searchMessagesFilter' .. filter
}
}
end
function TD1function.searchSecretMessages(chat_id, query, from_search_id, limit, filter)
local filter = filter or 'Empty'
return TD2function.run_table{
TD = 'searchSecretMessages',
chat_id = chat_id or 0,
query = tostring(query),
from_search_id = from_search_id or 0,
limit = TD1function.setLimit(100, limit),
filter = {
TD = 'searchMessagesFilter' .. filter
}
}
end
function TD1function.deleteChatHistory(chat_id, remove_from_chat_list)
return TD2function.run_table{
TD = 'deleteChatHistory',
chat_id = chat_id,
remove_from_chat_list = remove_from_chat_list
}
end
function TD1function.searchCallMessages(from_message_id, limit, only_missed)
return TD2function.run_table{
TD = 'searchCallMessages',
from_message_id = from_message_id or 0,
limit = TD1function.setLimit(100, limit),
only_missed = only_missed
}
end
function TD1function.getChatMessageByDate(chat_id, date)
return TD2function.run_table{
TD = 'getChatMessageByDate',
chat_id = chat_id,
date = date
}
end
function TD1function.getPublicMessageLink(chat_id, message_id, for_album)
return TD2function.run_table{
TD = 'getPublicMessageLink',
chat_id = chat_id,
message_id = message_id,
for_album = for_album
}
end
function TD1function.sendMessageAlbum(chat_id, reply_to_message_id, input_message_contents, disable_notification, from_background)
return TD2function.run_table{
TD = 'sendMessageAlbum',
chat_id = chat_id,
reply_to_message_id = reply_to_message_id or 0,
disable_notification = disable_notification,
from_background = from_background,
input_message_contents = TD1function.vectorize(input_message_contents)
}
end
function TD1function.sendBotStartMessage(bot_user_id, chat_id, parameter)
return TD2function.run_table{
TD = 'sendBotStartMessage',
bot_user_id = bot_user_id,
chat_id = chat_id,
parameter = tostring(parameter)
}
end
function TD1function.sendInlineQueryResultMessage(chat_id, reply_to_message_id, disable_notification, from_background, query_id, result_id)
return TD2function.run_table{
TD = 'sendInlineQueryResultMessage',
chat_id = chat_id,
reply_to_message_id = reply_to_message_id,
disable_notification = disable_notification,
from_background = from_background,
query_id = query_id,
result_id = tostring(result_id)
}
end
function TD1function.forwardMessages(chat_id, from_chat_id, message_ids, disable_notification, from_background, as_album, send_copy, remove_caption)
return TD2function.run_table{
TD = 'forwardMessages',
chat_id = chat_id,
from_chat_id = from_chat_id,
message_ids = TD1function.vectorize(message_ids),
disable_notification = disable_notification,
from_background = from_background,
as_album = as_album,
send_copy = send_copy,
remove_caption = remove_caption
}
end
function TD1function.sendChatSetTtlMessage(chat_id, ttl)
return TD2function.run_table{
TD = 'sendChatSetTtlMessage',
chat_id = chat_id,
ttl = ttl
}
end
function TD1function.sendChatScreenshotTakenNotification(chat_id)
return TD2function.run_table{
TD = 'sendChatScreenshotTakenNotification',
chat_id = chat_id
}
end
function TD1function.deleteMessages(chat_id, message_ids, revoke)
return TD2function.run_table{
TD = 'deleteMessages',
chat_id = chat_id,
message_ids = TD1function.vectorize(message_ids),
revoke = revoke
}
end
function TD1function.deleteChatMessagesFromUser(chat_id, user_id)
return TD2function.run_table{
TD = 'deleteChatMessagesFromUser',
chat_id = chat_id,
user_id = user_id
}
end
function TD1function.editMessageText(chat_id, message_id, text, parse_mode, disable_web_page_preview, clear_draft, reply_markup)
local TD_body = {
TD = 'editMessageText',
chat_id = chat_id,
message_id = message_id,
reply_markup = reply_markup,
input_message_content = {
TD = 'inputMessageText',
disable_web_page_preview = disable_web_page_preview,
text = {
  text = text
},
clear_draft = clear_draft
}
}
if parse_mode then
TD_body.input_message_content.text = TD1function.parseTextEntities(text, parse_mode)
end
return TD2function.run_table(TD_body)
end
function TD1function.editMessageReplyMarkup(chat_id, message_id, reply_markup)
local TD_body = {
TD = 'editMessageReplyMarkup',
chat_id = chat_id,
message_id = message_id,
reply_markup = reply_markup
}
return TD2function.run_table(TD_body)
end
function TD1function.editMessageCaption(chat_id, message_id, caption, parse_mode, reply_markup)
local TD_body = {
TD = 'editMessageCaption',
chat_id = chat_id,
message_id = message_id,
reply_markup = reply_markup,
caption = caption
}
if parse_mode then
TD_body.caption = TD1function.parseTextEntities(text,parse_mode)
end
return TD2function.run_table(TD_body)
end
function TD1function.getTextEntities(text)
return TD2function.run_table{
TD = 'getTextEntities',
text = tostring(text)
}
end
function TD1function.getFileMimeType(file_name)
return TD2function.run_table{
TD = 'getFileMimeType',
file_name = tostring(file_name)
}
end
function TD1function.getFileExtension(mime_type)
return TD2function.run_table{
TD = 'getFileExtension',
mime_type = tostring(mime_type)
}
end
function TD1function.getInlineQueryResults(bot_user_id, chat_id, latitude, longitude, query, offset)
return TD2function.run_table{
TD = 'getInlineQueryResults',
bot_user_id = bot_user_id,
chat_id = chat_id,
user_location = {
TD = 'location',
latitude = latitude,
longitude = longitude
},
query = tostring(query),
offset = tostring(offset)
}
end
function TD1function.answerCallbackQuery(callback_query_id, text, show_alert, url, cache_time)
return TD2function.run_table{
TD = 'answerCallbackQuery',
  callback_query_id = callback_query_id,
  show_alert = show_alert,
  cache_time = cache_time,
  text = text,
  url = url,
}
end
function TD1function.getCallbackQueryAnswer(chat_id, message_id, payload, data, game_short_name)
return TD2function.run_table{
TD = 'getCallbackQueryAnswer',
chat_id = chat_id,
message_id = message_id,
payload = {
TD = 'callbackQueryPayload' .. payload,
data = data,
game_short_name = game_short_name
}
}
end
function TD1function.deleteChatReplyMarkup(chat_id, message_id)
return TD2function.run_table{
TD = 'deleteChatReplyMarkup',
chat_id = chat_id,
message_id = message_id
}
end
function TD1function.sendChatAction(chat_id, action, progress)
return TD2function.run_table{
TD = 'sendChatAction',
chat_id = chat_id,
action = {
TD = 'chatAction' .. action,
progress = progress or 100
}
}
end
function TD1function.openChat(chat_id)
return TD2function.run_table{
TD = 'openChat',
chat_id = chat_id
}
end
function TD1function.closeChat(chat_id)
return TD2function.run_table{
TD = 'closeChat',
chat_id = chat_id
}
end
function TD1function.viewMessages(chat_id, message_ids, force_read)
return TD2function.run_table{
TD = 'viewMessages',
chat_id = chat_id,
message_ids = TD1function.vectorize(message_ids),
force_read = force_read
}
end
function TD1function.openMessageContent(chat_id, message_id)
return TD2function.run_table{
TD = 'openMessageContent',
chat_id = chat_id,
message_id = message_id
}
end
function TD1function.readAllChatMentions(chat_id)
return TD2function.run_table{
TD = 'readAllChatMentions',
chat_id = chat_id
}
end
function TD1function.createPrivateChat(user_id, force)
return TD2function.run_table{
TD = 'createPrivateChat',
user_id = user_id,
force = force
}
end
function TD1function.createBasicGroupChat(basic_group_id, force)
return TD2function.run_table{
TD = 'createBasicGroupChat',
basic_group_id = TD1function.getChatId(basic_group_id).id,
force = force
}
end
function TD1function.createSupergroupChat(supergroup_id, force)
return TD2function.run_table{
TD = 'createSupergroupChat',
supergroup_id = TD1function.getChatId(supergroup_id).id,
force = force
}
end
function TD1function.createSecretChat(secret_chat_id)
return TD2function.run_table{
TD = 'createSecretChat',
secret_chat_id = secret_chat_id
}
end
function TD1function.createNewBasicGroupChat(user_ids, title)
return TD2function.run_table{
TD = 'createNewBasicGroupChat',
user_ids = TD1function.vectorize(user_ids),
title = tostring(title)
}
end
function TD1function.createNewSupergroupChat(title, is_channel, description)
return TD2function.run_table{
TD = 'createNewSupergroupChat',
title = tostring(title),
is_channel = is_channel,
description = tostring(description)
}
end
function TD1function.createNewSecretChat(user_id)
return TD2function.run_table{
TD = 'createNewSecretChat',
user_id = tonumber(user_id)
}
end
function TD1function.upgradeBasicGroupChatToSupergroupChat(chat_id)
return TD2function.run_table{
TD = 'upgradeBasicGroupChatToSupergroupChat',
chat_id = chat_id
}
end
function TD1function.setChatPermissions(chat_id, can_send_messages, can_send_media_messages, can_send_polls, can_send_other_messages, can_add_web_page_previews, can_change_info, can_invite_users, can_pin_messages)
return TD2function.run_table{
TD = 'setChatPermissions',
chat_id = chat_id,
 permissions = {
can_send_messages = can_send_messages,
can_send_media_messages = can_send_media_messages,
can_send_polls = can_send_polls,
can_send_other_messages = can_send_other_messages,
can_add_web_page_previews = can_add_web_page_previews,
can_change_info = can_change_info,
can_invite_users = can_invite_users,
can_pin_messages = can_pin_messages,
}
}
end
function TD1function.setChatTitle(chat_id, title)
return TD2function.run_table{
TD = 'setChatTitle',
chat_id = chat_id,
title = tostring(title)
}
end
function TD1function.setChatPhoto(chat_id, photo)
return TD2function.run_table{
TD = 'setChatPhoto',
chat_id = chat_id,
photo = {TD = 'inputChatPhotoStatic', photo = getInputFile(photo)}
}
end 
function TD1function.setChatDraftMessage(chat_id, reply_to_message_id, text, parse_mode, disable_web_page_preview, clear_draft)
local TD_body = {
TD = 'setChatDraftMessage',
chat_id = chat_id,
draft_message = {
TD = 'draftMessage',
reply_to_message_id = reply_to_message_id,
input_message_text = {
TD = 'inputMessageText',
  disable_web_page_preview = disable_web_page_preview,
  text = {text = text},
  clear_draft = clear_draft
}
}
}
if parse_mode then
TD_body.draft_message.input_message_text.text = TD1function.parseTextEntities(text, parse_mode)
end
return TD2function.run_table(TD_body)
end
function TD1function.toggleChatIsPinned(chat_id, is_pinned)
return TD2function.run_table{
TD = 'toggleChatIsPinned',
chat_id = chat_id,
is_pinned = is_pinned
}
end
function TD1function.setChatClientData(chat_id, client_data)
return TD2function.run_table{
TD = 'setChatClientData',
chat_id = chat_id,
client_data = tostring(client_data)
}
end
function TD1function.addChatMember(chat_id, user_id, forward_limit)
return TD2function.run_table{
TD = 'addChatMember',
chat_id = chat_id,
user_id = user_id,
forward_limit = TD1function.setLimit(300, forward_limit)
}
end
function TD1function.addChatMembers(chat_id, user_ids)
return TD2function.run_table{
TD = 'addChatMembers',
chat_id = chat_id,
user_ids = TD1function.vectorize(user_ids)
}
end
function TD1function.setChatMemberStatus(chat_id, user_id, status, right)
local right = right and TD1function.vectorize(right) or {}
local status = string.lower(status)
if status == 'creator' then
chat_member_status = {
TD = 'chatMemberStatusCreator',
is_member = right[1] or 1
}
elseif status == 'administrator' then
chat_member_status = {
TD = 'chatMemberStatusAdministrator',
can_be_edited = right[1] or 1,
can_change_info = right[2] or 0,
can_post_messages = right[3] or 1,
can_edit_messages = right[4] or 1,
can_delete_messages = right[5] or 0,
can_invite_users = right[6] or 1,
can_restrict_members = right[7] or 0,
can_pin_messages = right[8] or 0,
can_manage_video_chats = right[9] or 0,
is_anonymous = right[10] or 0,
can_manage_chat = right[11] or 0,
can_promote_members = right[12] or 0,
custom_title = tostring(right[13]) or ''
}
elseif status == 'restricted' then
chat_member_status = {
permissions = {
TD = 'chatPermissions',
  can_send_polls = right[2] or 0,
  can_add_web_page_previews = right[3] or 1,
  can_change_info = right[4] or 0,
  can_invite_users = right[5] or 1,
  can_pin_messages = right[6] or 0,
  can_send_media_messages = right[7] or 1,
  can_send_messages = right[8] or 1,
  can_send_other_messages = right[9] or 1
},
is_member = right[1] or 1,
restricted_until_date = right[10] or 0,
TD = 'chatMemberStatusRestricted'
}
elseif status == 'banned' then
chat_member_status = {
TD = 'chatMemberStatusBanned',
banned_until_date = right[1] or 0
}
end
return TD2function.run_table{
TD = 'setChatMemberStatus',
chat_id = chat_id,
member_id = {_='messageSenderUser', user_id = user_id},
status = chat_member_status or {}
}
end
function TD1function.SetAdmin(chat_id, user_id,right)
chat_member_status = {
TD = 'chatMemberStatusAdministrator',
is_member = true,
can_be_edited = right[1] or 1,
can_change_info = right[2] or 1,
can_post_messages = right[3] or 1,
can_edit_messages = right[4] or 1,
can_delete_messages = right[5] or 1,
can_invite_users = right[6] or 1,
can_restrict_members = right[7] or 1,
can_pin_messages = right[8] or 1,
can_manage_video_chats = right[9] or 1,
is_anonymous = right[10] or 1,
can_manage_chat = right[11] or 1,
can_promote_members = right[12] or 0,
custom_title = tostring(right[13]) or ''
}
return TD2function.run_table{
TD = 'setChatMemberStatus',
chat_id = chat_id,
user_id = user_id,
status = chat_member_status or {}
}
end

function TD1function.getChatMember(chat_id, user_id)
return TD2function.run_table{
TD = 'getChatMember',
chat_id = chat_id,
member_id = {_='messageSenderUser', user_id = user_id}
}
end 
function TD1function.searchChatMembers(chat_id, query, limit)
return TD2function.run_table{
TD = 'searchChatMembers',
chat_id = chat_id,
query = tostring(query),
limit = TD1function.setLimit(200, limit)
}
end
function TD1function.getChatAdministrators(chat_id)
return TD2function.run_table{
TD = 'getChatAdministrators',
chat_id = chat_id
}
end
function TD1function.setPinnedChats(chat_ids)
return TD2function.run_table{
TD = 'setPinnedChats',
chat_ids = TD1function.vectorize(chat_ids)
}
end
function TD1function.downloadFile(file_id, priority)
return TD2function.run_table{
TD = 'downloadFile',
file_id = file_id,
priority = priority or 32
}
end
function TD1function.cancelDownloadFile(file_id, only_if_pending)
return TD2function.run_table{
TD = 'cancelDownloadFile',
file_id = file_id,
only_if_pending = only_if_pending
}
end
function TD1function.uploadFile(file, file_type, priority)
local ftype = file_type or 'Unknown'
return TD2function.run_table{
TD = 'uploadFile',
file = TD1function.getInputFile(file),
file_type = {
TD = 'fileType' .. ftype
},
priority = priority or 32
}
end
function TD1function.cancelUploadFile(file_id)
return TD2function.run_table{
TD = 'cancelUploadFile',
file_id = file_id
}
end
function TD1function.deleteFile(file_id)
return TD2function.run_table{
TD = 'deleteFile',
file_id = file_id
}
end
function TD1function.generateChatInviteLink(chat_id,name,expire_date,member_limit,creates_join_request)
return TD2function.run_table{
TD = 'createChatInviteLink',
chat_id = chat_id,
name = tostring(name),
expire_date = tonumber(expire_date),
member_limit = tonumber(member_limit),
creates_join_request = creates_join_request
}
end 
function TD1function.joinChatByUsernam(username)
if type(username) == 'string' and 5 <= #username then
local result = TD1function.searchPublicChat(username)
if result.type and result.type.TD == 'chatTypeSupergroup' then
return TD2function.run_table{
TD = 'joinChat',
  chat_id = result.id
}
else
return result
end
end
end
function TD1function.checkChatInviteLink(invite_link)
return TD2function.run_table{
TD = 'checkChatInviteLink',
invite_link = tostring(invite_link)
}
end
function TD1function.joinChatByInviteLink(invite_link)
return TD2function.run_table{
TD = 'joinChatByInviteLink',
invite_link = tostring(invite_link)
}
end
function TD1function.leaveChat(chat_id)
return TD2function.run_table{
TD = 'leaveChat',
chat_id = chat_id
}
end
function TD1function.createCall(user_id, udp_p2p, udp_reflector, min_layer, max_layer)
return TD2function.run_table{
TD = 'createCall',
user_id = user_id,
protocol = {
TD = 'callProtocol',
udp_p2p = udp_p2p,
udp_reflector = udp_reflector,
min_layer = min_layer or 65,
max_layer = max_layer or 65
}
}
end
function TD1function.acceptCall(call_id, udp_p2p, udp_reflector, min_layer, max_layer)
return TD2function.run_table{
TD = 'acceptCall',
call_id = call_id,
protocol = {
TD = 'callProtocol',
udp_p2p = udp_p2p,
udp_reflector = udp_reflector,
min_layer = min_layer or 65,
max_layer = max_layer or 65
}
}
end
function TD1function.blockUser(user_id)
return TD2function.run_table{
TD = 'blockUser',
user_id = user_id
}
end
function TD1function.unblockUser(user_id)
return TD2function.run_table{
TD = 'unblockUser',
user_id = user_id
}
end
function TD1function.getBlockedUsers(offset, limit)
return TD2function.run_table{
TD = 'getBlockedUsers',
offset = offset or 0,
limit = TD1function.setLimit(100, limit)
}
end
function TD1function.getContacts()
return TD2function.run_table{
TD = 'getContacts'
}
end
function TD1function.importContacts(contacts)
local result = {}
  for key, value in pairs(contacts) do
result[#result + 1] = {
TD = 'contact',
phone_number = tostring(value.phone_number),
first_name = tostring(value.first_name),
last_name = tostring(value.last_name),
user_id = value.user_id or 0
}
end
return TD2function.run_table{
TD = 'importContacts',
contacts = result
}
end
function TD1function.searchContacts(query, limit)
return TD2function.run_table{
TD = 'searchContacts',
query = tostring(query),
limit = limit
}
end
function TD1function.removeContacts(user_ids)
return TD2function.run_table{
TD = 'removeContacts',
user_ids = TD1function.vectorize(user_ids)
}
end
function TD1function.getImportedContactCount()
return TD2function.run_table{
TD = 'getImportedContactCount'
}
end
function TD1function.changeImportedContacts(phone_number, first_name, last_name, user_id)
return TD2function.run_table{
TD = 'changeImportedContacts',
contacts = {
TD = 'contact',
phone_number = tostring(phone_number),
first_name = tostring(first_name),
last_name = tostring(last_name),
user_id = user_id or 0
}
}
end
function TD1function.clearImportedContacts()
return TD2function.run_table{
TD = 'clearImportedContacts'
}
end
function TD1function.getUserProfilePhotos(user_id, offset, limit)
return TD2function.run_table{
TD = 'getUserProfilePhotos',
user_id = user_id,
offset = offset or 0,
limit = TD1function.setLimit(100, limit)
}
end
function TD1function.getStickers(emoji, limit)
return TD2function.run_table{
TD = 'getStickers',
emoji = tostring(emoji),
limit = TD1function.setLimit(100, limit)
}
end
function TD1function.searchStickers(emoji, limit)
return TD2function.run_table{
TD = 'searchStickers',
emoji = tostring(emoji),
limit = limit
}
end
function TD1function.getArchivedStickerSets(is_masks, offset_sticker_set_id, limit)
return TD2function.run_table{
TD = 'getArchivedStickerSets',
is_masks = is_masks,
offset_sticker_set_id = offset_sticker_set_id,
limit = limit
}
end
function TD1function.getTrendingStickerSets()
return TD2function.run_table{
TD = 'getTrendingStickerSets'
}
end
function TD1function.getAttachedStickerSets(file_id)
return TD2function.run_table{
TD = 'getAttachedStickerSets',
file_id = file_id
}
end
function TD1function.getStickerSet(set_id)
return TD2function.run_table{
TD = 'getStickerSet',
set_id = set_id
}
end
function TD1function.searchStickerSet(name)
return TD2function.run_table{
TD = 'searchStickerSet',
name = tostring(name)
}
end
function TD1function.searchInstalledStickerSets(is_masks, query, limit)
return TD2function.run_table{
TD = 'searchInstalledStickerSets',
is_masks = is_masks,
query = tostring(query),
limit = limit
}
end
function TD1function.searchStickerSets(query)
return TD2function.run_table{
TD = 'searchStickerSets',
query = tostring(query)
}
end
function TD1function.changeStickerSet(set_id, is_installed, is_archived)
return TD2function.run_table{
TD = 'changeStickerSet',
set_id = set_id,
is_installed = is_installed,
is_archived = is_archived
}
end
function TD1function.viewTrendingStickerSets(sticker_set_ids)
return TD2function.run_table{
TD = 'viewTrendingStickerSets',
sticker_set_ids = TD1function.vectorize(sticker_set_ids)
}
end
function TD1function.reorderInstalledStickerSets(is_masks, sticker_set_ids)
return TD2function.run_table{
TD = 'reorderInstalledStickerSets',
is_masks = is_masks,
sticker_set_ids = TD1function.vectorize(sticker_set_ids)
}
end
function TD1function.getRecentStickers(is_attached)
return TD2function.run_table{
TD = 'getRecentStickers',
is_attached = is_attached
}
end
function TD1function.addRecentSticker(is_attached, sticker)
return TD2function.run_table{
TD = 'addRecentSticker',
is_attached = is_attached,
sticker = TD1function.getInputFile(sticker)
}
end
function TD1function.clearRecentStickers(is_attached)
return TD2function.run_table{
TD = 'clearRecentStickers',
is_attached = is_attached
}
end
function TD1function.getFavoriteStickers()
return TD2function.run_table{
TD = 'getFavoriteStickers'
}
end
function TD1function.addFavoriteSticker(sticker)
return TD2function.run_table{
TD = 'addFavoriteSticker',
sticker = TD1function.getInputFile(sticker)
}
end
function TD1function.removeFavoriteSticker(sticker)
return TD2function.run_table{
TD = 'removeFavoriteSticker',
sticker = TD1function.getInputFile(sticker)
}
end
function TD1function.getStickerEmojis(sticker)
return TD2function.run_table{
TD = 'getStickerEmojis',
sticker = TD1function.getInputFile(sticker)
}
end
function TD1function.getSavedAnimations()
return TD2function.run_table{
TD = 'getSavedAnimations'
}
end
function TD1function.addSavedAnimation(animation)
return TD2function.run_table{
TD = 'addSavedAnimation',
animation = TD1function.getInputFile(animation)
}
end
function TD1function.removeSavedAnimation(animation)
return TD2function.run_table{
TD = 'removeSavedAnimation',
animation = TD1function.getInputFile(animation)
}
end
function TD1function.getRecentInlineBots()
return TD2function.run_table{
TD = 'getRecentInlineBots'
}
end
function TD1function.searchHashtags(prefix, limit)
return TD2function.run_table{
TD = 'searchHashtags',
prefix = tostring(prefix),
limit = limit
}
end
function TD1function.removeRecentHashtag(hashtag)
return TD2function.run_table{
TD = 'removeRecentHashtag',
hashtag = tostring(hashtag)
}
end
function TD1function.getWebPagePreview(text)
return TD2function.run_table{
TD = 'getWebPagePreview',
text = {
text = text
}
}
end
function TD1function.getWebPageInstantView(url, force_full)
return TD2function.run_table{
TD = 'getWebPageInstantView',
url = tostring(url),
force_full = force_full
}
end
function TD1function.getNotificationSettings(scope, chat_id)
return TD2function.run_table{
TD = 'getNotificationSettings',
scope = {
TD = 'notificationSettingsScope' .. scope,
chat_id = chat_id
}
}
end
function TD1function.setNotificationSettings(scope, chat_id, mute_for, sound, show_preview)
return TD2function.run_table{
TD = 'setNotificationSettings',
scope = {
TD = 'notificationSettingsScope' .. scope,
chat_id = chat_id
},
notification_settings = {
TD = 'notificationSettings',
mute_for = mute_for,
sound = tostring(sound),
show_preview = show_preview
}
}
end
function TD1function.resetAllNotificationSettings()
return TD2function.run_table{
TD = 'resetAllNotificationSettings'
}
end
function TD1function.setProfilePhoto(photo)
return TD2function.run_table{
TD = 'setProfilePhoto',
photo = TD1function.getInputFile(photo)
}
end
function TD1function.deleteProfilePhoto(profile_photo_id)
return TD2function.run_table{
TD = 'deleteProfilePhoto',
profile_photo_id = profile_photo_id
}
end
function TD1function.setName(first_name, last_name)
return TD2function.run_table{
TD = 'setName',
first_name = tostring(first_name),
last_name = tostring(last_name)
}
end
function TD1function.setBio(bio)
return TD2function.run_table{
TD = 'setBio',
bio = tostring(bio)
}
end
function TD1function.setUsername(username)
return TD2function.run_table{
TD = 'setUsername',
username = tostring(username)
}
end
function TD1function.getActiveSessions()
return TD2function.run_table{
TD = 'getActiveSessions'
}
end
function TD1function.terminateAllOtherSessions()
return TD2function.run_table{
TD = 'terminateAllOtherSessions'
}
end
function TD1function.terminateSession(session_id)
return TD2function.run_table{
TD = 'terminateSession',
session_id = session_id
}
end
function TD1function.toggleBasicGroupAdministrators(basic_group_id, everyone_is_administrator)
return TD2function.run_table{
TD = 'toggleBasicGroupAdministrators',
basic_group_id = TD1function.getChatId(basic_group_id).id,
everyone_is_administrator = everyone_is_administrator
}
end
function TD1function.setSupergroupUsername(supergroup_id, username)
return TD2function.run_table{
TD = 'setSupergroupUsername',
supergroup_id = TD1function.getChatId(supergroup_id).id,
username = tostring(username)
}
end
function TD1function.setSupergroupStickerSet(supergroup_id, sticker_set_id)
return TD2function.run_table{
TD = 'setSupergroupStickerSet',
supergroup_id = TD1function.getChatId(supergroup_id).id,
sticker_set_id = sticker_set_id
}
end
function TD1function.toggleSupergroupInvites(supergroup_id, anyone_can_invite)
return TD2function.run_table{
TD = 'toggleSupergroupInvites',
supergroup_id = TD1function.getChatId(supergroup_id).id,
anyone_can_invite = anyone_can_invite
}
end
function TD1function.toggleSupergroupSignMessages(supergroup_id, sign_messages)
return TD2function.run_table{
TD = 'toggleSupergroupSignMessages',
supergroup_id = TD1function.getChatId(supergroup_id).id,
sign_messages = sign_messages
}
end
function TD1function.toggleSupergroupIsAllHistoryAvailable(supergroup_id, is_all_history_available)
return TD2function.run_table{
TD = 'toggleSupergroupIsAllHistoryAvailable',
supergroup_id = TD1function.getChatId(supergroup_id).id,
is_all_history_available = is_all_history_available
}
end
function TD1function.setChatDescription(chat_id, description)
return TD2function.run_table{
TD = 'setChatDescription',
chat_id = chat_id,
description = tostring(description)
}
end
function TD1function.pinChatMessage(chat_id, message_id, disable_notification)
return TD2function.run_table{
TD = 'pinChatMessage',
chat_id = chat_id,
message_id = message_id,
disable_notification = disable_notification
}
end
function TD1function.unpinChatMessage(chat_id)
return TD2function.run_table{
TD = 'unpinChatMessage',
chat_id = chat_id
}
end
function TD1function.reportSupergroupSpam(supergroup_id, user_id, message_ids)
return TD2function.run_table{
TD = 'reportSupergroupSpam',
supergroup_id = TD1function.getChatId(supergroup_id).id,
user_id = user_id,
message_ids = TD1function.vectorize(message_ids)
}
end
function TD1function.getSupergroupMembers(supergroup_id, filter, query, offset, limit)
local filter = filter or 'Recent'
return TD2function.run_table{
TD = 'getSupergroupMembers',
supergroup_id = TD1function.getChatId(supergroup_id).id,
filter = {
TD = 'supergroupMembersFilter' .. filter,
query = query
},
offset = offset or 0,
limit = TD1function.setLimit(200, limit)
}
end
function TD1function.deleteSupergroup(supergroup_id)
return TD2function.run_table{
TD = 'deleteSupergroup',
supergroup_id = TD1function.getChatId(supergroup_id).id
}
end
function TD1function.closeSecretChat(secret_chat_id)
return TD2function.run_table{
TD = 'closeSecretChat',
secret_chat_id = secret_chat_id
}
end
function TD1function.getChatEventLog(chat_id, query, from_event_id, limit, filters, user_ids)
local filters = filters or {1,1,1,1,1,1,1,1,1,1}
return TD2function.run_table{
TD = 'getChatEventLog',
chat_id = chat_id,
query = tostring(query) or '',
from_event_id = from_event_id or 0,
limit = TD1function.setLimit(100, limit),
filters = {
TD = 'chatEventLogFilters',
message_edits = filters[0],
message_deletions = filters[1],
message_pins = filters[2],
member_joins = filters[3],
member_leaves = filters[4],
member_invites = filters[5],
member_promotions = filters[6],
member_restrictions = filters[7],
info_changes = filters[8],
setting_changes = filters[9]
},
user_ids = TD1function.vectorize(user_ids)
}
end
function TD1function.getSavedOrderInfo()
return TD2function.run_table{
TD = 'getSavedOrderInfo'
}
end
function TD1function.deleteSavedOrderInfo()
return TD2function.run_table{
TD = 'deleteSavedOrderInfo'
}
end
function TD1function.deleteSavedCredentials()
return TD2function.run_table{
TD = 'deleteSavedCredentials'
}
end
function TD1function.getSupportUser()
return TD2function.run_table{
TD = 'getSupportUser'
}
end
function TD1function.getWallpapers()
return TD2function.run_table{
TD = 'getWallpapers'
}
end
function TD1function.setUserPrivacySettingRules(setting, rules, allowed_user_ids, restricted_user_ids)
local setting_rules = {
[0] = {
TD = 'userPrivacySettingRule' .. rules
}
}
if allowed_user_ids then
setting_rules[#setting_rules + 1] = {
{
TD = 'userPrivacySettingRuleAllowUsers',
  user_ids = TD1function.vectorize(allowed_user_ids)
}
}
elseif restricted_user_ids then
setting_rules[#setting_rules + 1] = {
{
TD = 'userPrivacySettingRuleRestrictUsers',
  user_ids = TD1function.vectorize(restricted_user_ids)
}
}
end
return TD2function.run_table{
TD = 'setUserPrivacySettingRules',
setting = {
TD = 'userPrivacySetting' .. setting
},
rules = {
TD = 'userPrivacySettingRules',
rules = setting_rules
}
}
end
function TD1function.getUserPrivacySettingRules(setting)
return TD2function.run_table{
TD = 'getUserPrivacySettingRules',
setting = {
TD = 'userPrivacySetting' .. setting
}
}
end
function TD1function.getOption(name)
return TD2function.run_table{
TD = 'getOption',
name = tostring(name)
}
end
function TD1function.setOption(name, option_value, value)
return TD2function.run_table{
TD = 'setOption',
name = tostring(name),
value = {
TD = 'optionValue' .. option_value,
value = value
}
}
end
function TD1function.setAccountTtl(ttl)
return TD2function.run_table{
TD = 'setAccountTtl',
ttl = {
TD = 'accountTtl',
days = ttl
}
}
end
function TD1function.getAccountTtl()
return TD2function.run_table{
TD = 'getAccountTtl'
}
end
function TD1function.deleteAccount(reason)
return TD2function.run_table{
TD = 'deleteAccount',
reason = tostring(reason)
}
end
function TD1function.getChatReportSpamState(chat_id)
return TD2function.run_table{
TD = 'getChatReportSpamState',
chat_id = chat_id
}
end
function TD1function.reportChat(chat_id, reason, text, message_ids)
return TD2function.run_table{
TD = 'reportChat',
chat_id = chat_id,
reason = {
TD = 'chatReportReason' .. reason,
text = text
},
message_ids = TD1function.vectorize(message_ids)
}
end
function TD1function.getStorageStatistics(chat_limit)
return TD2function.run_table{
TD = 'getStorageStatistics',
chat_limit = chat_limit
}
end
function TD1function.getStorageStatisticsFast()
return TD2function.run_table{
TD = 'getStorageStatisticsFast'
}
end
function TD1function.optimizeStorage(size, ttl, count, immunity_delay, file_type, chat_ids, exclude_chat_ids, chat_limit)
local file_type = file_type or ''
return TD2function.run_table{
TD = 'optimizeStorage',
size = size or -1,
ttl = ttl or -1,
count = count or -1,
immunity_delay = immunity_delay or -1,
file_type = {
TD = 'fileType' .. file_type
},
chat_ids = TD1function.vectorize(chat_ids),
exclude_chat_ids = TD1function.vectorize(exclude_chat_ids),
chat_limit = chat_limit
}
end
function TD1function.setNetworkType(type)
return TD2function.run_table{
TD = 'setNetworkType',
type = {
TD = 'networkType' .. type
},
}
end
function TD1function.getNetworkStatistics(only_current)
return TD2function.run_table{
TD = 'getNetworkStatistics',
only_current = only_current
}
end
function TD1function.addNetworkStatistics(entry, file_type, network_type, sent_bytes, received_bytes, duration)
local file_type = file_type or 'None'
return TD2function.run_table{
TD = 'addNetworkStatistics',
entry = {
TD = 'networkStatisticsEntry' .. entry,
file_type = {
TD = 'fileType' .. file_type
},
network_type = {
TD = 'networkType' .. network_type
},
sent_bytes = sent_bytes,
received_bytes = received_bytes,
duration = duration
}
}
end
function TD1function.resetNetworkStatistics()
return TD2function.run_table{
TD = 'resetNetworkStatistics'
}
end
function TD1function.getCountryCode()
return TD2function.run_table{
TD = 'getCountryCode'
}
end
function TD1function.getInviteText()
return TD2function.run_table{
TD = 'getInviteText'
}
end
function TD1function.getTermsOfService()
return TD2function.run_table{
TD = 'getTermsOfService'
}
end
function TD1function.sendText(chat_id, reply_to_message_id, text, parse_mode, disable_web_page_preview, clear_draft, disable_notification, from_background, reply_markup)
local input_message_content = {
TD = 'inputMessageText',
disable_web_page_preview = disable_web_page_preview,
text = {text = text},
clear_draft = clear_draft
}
return TD1function.sendMessage(chat_id, reply_to_message_id, input_message_content, parse_mode, disable_notification, from_background, reply_markup)
end
function TD1function.sendAnimation(chat_id, reply_to_message_id, animation, caption, parse_mode, duration, width, height, thumbnail, thumb_width, thumb_height, disable_notification, from_background, reply_markup)
local input_message_content = {
TD = 'inputMessageAnimation',
animation = TD1function.getInputFile(animation),
thumbnail = {
TD = 'inputThumbnail',
thumbnail = TD1function.getInputFile(thumbnail),
width = thumb_width,
height = thumb_height
},
caption = {text = caption},
duration = duration,
width = width,
height = height
}
return TD1function.sendMessage(chat_id, reply_to_message_id, input_message_content, parse_mode, disable_notification, from_background, reply_markup)
end
function TD1function.sendAudio(chat_id, reply_to_message_id, audio, caption, parse_mode, duration, title, performer, thumbnail, thumb_width, thumb_height, disable_notification, from_background, reply_markup)
local input_message_content = {
TD = 'inputMessageAudio',
audio = TD1function.getInputFile(audio),
album_cover_thumbnail = {
TD = 'inputThumbnail',
thumbnail = TD1function.getInputFile(thumbnail),
width = thumb_width,
height = thumb_height
},
caption = {text = caption},
duration = duration,
title = tostring(title),
performer = tostring(performer)
}
return TD1function.sendMessage(chat_id, reply_to_message_id, input_message_content, parse_mode, disable_notification, from_background, reply_markup)
end
function TD1function.sendDocument(chat_id, reply_to_message_id, document, caption, parse_mode, thumbnail, thumb_width, thumb_height, disable_notification, from_background, reply_markup)
local input_message_content = {
TD = 'inputMessageDocument',
document = TD1function.getInputFile(document),
thumbnail = {
TD = 'inputThumbnail',
thumbnail = TD1function.getInputFile(thumbnail),
width = thumb_width,
height = thumb_height
},
caption = {text = caption}
}
return TD1function.sendMessage(chat_id, reply_to_message_id, input_message_content, parse_mode, disable_notification, from_background, reply_markup)
end
function TD1function.sendPhoto(chat_id, reply_to_message_id, photo, caption, parse_mode, added_sticker_file_ids, width, height, ttl, thumbnail, thumb_width, thumb_height, disable_notification, from_background, reply_markup)
local input_message_content = {
TD = 'inputMessagePhoto',
photo = TD1function.getInputFile(photo),
thumbnail = {
TD = 'inputThumbnail',
thumbnail = TD1function.getInputFile(thumbnail),
width = thumb_width,
height = thumb_height
},
caption = {text = caption},
added_sticker_file_ids = TD1function.vectorize(added_sticker_file_ids),
width = width,
height = height,
ttl = ttl or 0
}
return TD1function.sendMessage(chat_id, reply_to_message_id, input_message_content, parse_mode, disable_notification, from_background, reply_markup)
end
function TD1function.sendSticker(chat_id, reply_to_message_id, sticker, width, height, disable_notification, thumbnail, thumb_width, thumb_height, from_background, reply_markup)
local input_message_content = {
TD = 'inputMessageSticker',
sticker = TD1function.getInputFile(sticker),
thumbnail = {
TD = 'inputThumbnail',
thumbnail = TD1function.getInputFile(thumbnail),
width = thumb_width,
height = thumb_height
},
width = width,
height = height
}
return TD1function.sendMessage(chat_id, reply_to_message_id, input_message_content, nil, disable_notification, from_background, reply_markup)
end
function TD1function.sendVideo(chat_id, reply_to_message_id, video, caption, parse_mode, added_sticker_file_ids, duration, width, height, ttl, thumbnail, thumb_width, thumb_height, disable_notification, from_background, reply_markup)
local input_message_content = {
TD = 'inputMessageVideo',
video = TD1function.getInputFile(video),
thumbnail = {
TD = 'inputThumbnail',
thumbnail = TD1function.getInputFile(thumbnail),
width = thumb_width,
height = thumb_height
},
caption = {text = caption},
added_sticker_file_ids = TD1function.vectorize(added_sticker_file_ids),
duration = duration,
width = width,
height = height,
ttl = ttl
}
return TD1function.sendMessage(chat_id, reply_to_message_id, input_message_content, parse_mode, disable_notification, from_background, reply_markup)
end
function TD1function.sendVideoNote(chat_id, reply_to_message_id, video_note, duration, length, thumbnail, thumb_width, thumb_height, disable_notification, from_background, reply_markup)
local input_message_content = {
TD = 'inputMessageVideoNote',
video_note = TD1function.getInputFile(video_note),
thumbnail = {
TD = 'inputThumbnail',
thumbnail = TD1function.getInputFile(thumbnail),
width = thumb_width,
height = thumb_height
},
duration = duration,
length = length
}
return TD1function.sendMessage(chat_id, reply_to_message_id, input_message_content, nil, disable_notification, from_background, reply_markup)
end
function TD1function.sendVoiceNote(chat_id, reply_to_message_id, voice_note, caption, parse_mode, duration, waveform, disable_notification, from_background, reply_markup)
local input_message_content = {
TD = 'inputMessageVoiceNote',
voice_note = TD1function.getInputFile(voice_note),
caption = {text = caption},
duration = duration,
waveform = waveform
}
return TD1function.sendMessage(chat_id, reply_to_message_id, input_message_content, parse_mode, disable_notification, from_background, reply_markup)
end
function TD1function.sendLocation(chat_id, reply_to_message_id, latitude, longitude, disable_notification, from_background, reply_markup)
local input_message_content = {
TD = 'inputMessageLocation',
location = {
TD = 'location',
latitude = latitude,
longitude = longitude
},
live_period = liveperiod
}
return TD1function.sendMessage(chat_id, reply_to_message_id, input_message_content, nil, disable_notification, from_background, reply_markup)
end
function TD1function.sendVenue(chat_id, reply_to_message_id, latitude, longitude, title, address, provider, id, disable_notification, from_background, reply_markup)
local input_message_content = {
TD = 'inputMessageVenue',
venue = {
TD = 'venue',
location = {
TD = 'location',
  latitude = latitude,
  longitude = longitude
},
title = tostring(title),
address = tostring(address),
provider = tostring(provider),
id = tostring(id)
}
}
return TD1function.sendMessage(chat_id, reply_to_message_id, input_message_content, nil, disable_notification, from_background, reply_markup)
end
function TD1function.sendContact(chat_id, reply_to_message_id, phone_number, first_name, last_name, user_id, disable_notification, from_background, reply_markup)
local input_message_content = {
TD = 'inputMessageContact',
contact = {
TD = 'contact',
phone_number = tostring(phone_number),
first_name = tostring(first_name),
last_name = tostring(last_name),
user_id = user_id
}
}
return TD1function.sendMessage(chat_id, reply_to_message_id, input_message_content, nil, disable_notification, from_background, reply_markup)
end
function TD1function.sendInvoice(chat_id, reply_to_message_id, invoice, title, description, photo_url, photo_size, photo_width, photo_height, payload, provider_token, provider_data, start_parameter, disable_notification, from_background, reply_markup)
local input_message_content = {
TD = 'inputMessageInvoice',
invoice = invoice,
title = tostring(title),
description = tostring(description),
photo_url = tostring(photo_url),
photo_size = photo_size,
photo_width = photo_width,
photo_height = photo_height,
payload = payload,
provider_token = tostring(provider_token),
provider_data = tostring(provider_data),
start_parameter = tostring(start_parameter)
}
return TD1function.sendMessage(chat_id, reply_to_message_id, input_message_content, nil, disable_notification, from_background, reply_markup)
end
function TD1function.sendForwarded(chat_id, reply_to_message_id, from_chat_id, message_id, in_game_share, disable_notification, from_background, reply_markup)
local input_message_content = {
TD = 'inputMessageForwarded',
from_chat_id = from_chat_id,
message_id = message_id,
in_game_share = in_game_share
}
return TD1function.sendMessage(chat_id, reply_to_message_id, input_message_content, nil, disable_notification, from_background, reply_markup)
end
function TD1function.sendPoll(chat_id, reply_to_message_id, question, options, pollType, is_anonymous, allow_multiple_answers)
local input_message_content = {
TD = 'inputMessagePoll',
is_anonymous = is_anonymous,
question = question,
type = {
TD = 'pollType'..pollType,
  allow_multiple_answers = allow_multiple_answers
},
options = options
}
return TD1function.sendMessage(chat_id, reply_to_message_id, input_message_content, parse_mode, disable_notification, from_background, reply_markup)
end
function TD1function.getPollVoters(chat_id, message_id, option_id, offset, limit)
return TD2function.run_table{
TD = 'getPollVoters',
chat_id = chat_id,
message_id = message_id,
option_id = option_id,
limit = TD1function.setLimit(50 , limit),
offset = offset
}
end
function TD1function.setPollAnswer(chat_id, message_id, option_ids)
return TD2function.run_table{
TD = 'setPollAnswer',
chat_id = chat_id,
message_id = message_id,
option_ids = option_ids
}
end
function TD1function.stopPoll(chat_id, message_id, reply_markup)
return TD2function.run_table{
TD = 'stopPoll',
chat_id = chat_id,
message_id = message_id,
reply_markup = reply_markup
}
end
function TD1function.getInputMessage(value)
if type(value) ~= 'table' then
return value
end
if type(value.type) == 'string' then
if value.parse_mode and value.caption then
caption = TD1function.parseTextEntities(value.caption, value.parse_mode)
  elseif value.caption and not value.parse_mode then
caption = {
  text = value.caption
}
  elseif value.parse_mode and value.text then
text = TD1function.parseTextEntities(value.text, value.parse_mode)
  elseif not value.parse_mode and value.text then
text = {
  text = value.text
}
end
value.type = string.lower(value.type)
if value.type == 'text' then
return {
TD = 'inputMessageText',
  disable_web_page_preview = value.disable_web_page_preview,
  text = text,
  clear_draft = value.clear_draft
}
  elseif value.type == 'animation' then
return {
TD = 'inputMessageAnimation',
  animation = TD1function.getInputFile(value.animation),
  thumbnail = {
TD = 'inputThumbnail',
thumbnail = TD1function.getInputFile(value.thumbnail),
width = value.thumb_width,
height = value.thumb_height
},
  caption = caption,
  duration = value.duration,
  width = value.width,
  height = value.height
}
  elseif value.type == 'audio' then
return {
TD = 'inputMessageAudio',
  audio = TD1function.getInputFile(value.audio),
  album_cover_thumbnail = {
TD = 'inputThumbnail',
thumbnail = TD1function.getInputFile(value.thumbnail),
width = value.thumb_width,
height = value.thumb_height
},
  caption = caption,
  duration = value.duration,
  title = tostring(value.title),
  performer = tostring(value.performer)
}
  elseif value.type == 'document' then
return {
TD = 'inputMessageDocument',
  document = TD1function.getInputFile(value.document),
  thumbnail = {
TD = 'inputThumbnail',
thumbnail = TD1function.getInputFile(value.thumbnail),
width = value.thumb_width,
height = value.thumb_height
},
  caption = caption
}
  elseif value.type == 'photo' then
return {
TD = 'inputMessagePhoto',
  photo = TD1function.getInputFile(value.photo),
  thumbnail = {
TD = 'inputThumbnail',
thumbnail = TD1function.getInputFile(value.thumbnail),
width = value.thumb_width,
height = value.thumb_height
},
  caption = caption,
  added_sticker_file_ids = TD1function.vectorize(value.added_sticker_file_ids),
  width = value.width,
  height = value.height,
  ttl = value.ttl or 0
}
  elseif value.text == 'video' then
return {
TD = 'inputMessageVideo',
  video = TD1function.getInputFile(value.video),
  thumbnail = {
TD = 'inputThumbnail',
thumbnail = TD1function.getInputFile(value.thumbnail),
width = value.thumb_width,
height = value.thumb_height
},
  caption = caption,
  added_sticker_file_ids = TD1function.vectorize(value.added_sticker_file_ids),
  duration = value.duration,
  width = value.width,
  height = value.height,
  ttl = value.ttl or 0
}
  elseif value.text == 'videonote' then
return {
TD = 'inputMessageVideoNote',
  video_note = TD1function.getInputFile(value.video_note),
  thumbnail = {
TD = 'inputThumbnail',
thumbnail = TD1function.getInputFile(value.thumbnail),
width = value.thumb_width,
height = value.thumb_height
},
  duration = value.duration,
  length = value.length
}
  elseif value.text == 'voice' then
return {
TD = 'inputMessageVoiceNote',
  voice_note = TD1function.getInputFile(value.voice_note),
  caption = caption,
  duration = value.duration,
  waveform = value.waveform
}
  elseif value.text == 'location' then
return {
TD = 'inputMessageLocation',
  location = {
TD = 'location',
latitude = value.latitude,
longitude = value.longitude
},
  live_period = value.liveperiod
}
  elseif value.text == 'contact' then
return {
TD = 'inputMessageContact',
  contact = {
TD = 'contact',
phone_number = tostring(value.phone_number),
first_name = tostring(value.first_name),
last_name = tostring(value.last_name),
user_id = value.user_id
}
}
  elseif value.text == 'contact' then
return {
TD = 'inputMessageContact',
  contact = {
TD = 'contact',
phone_number = tostring(value.phone_number),
first_name = tostring(value.first_name),
last_name = tostring(value.last_name),
user_id = value.user_id
}
}
end
end
end
function TD1function.editInlineMessageText(inline_message_id, input_message_content, reply_markup)
return TD2function.run_table{
TD = 'editInlineMessageText',
input_message_content = TD1function.getInputMessage(input_message_content),
reply_markup = reply_markup
}
end
function TD1function.answerInlineQuery(inline_query_id, results, next_offset, switch_pm_text, switch_pm_parameter, is_personal, cache_time)
local answerInlineQueryResults = {}
  for key, value in pairs(results) do
local newAnswerInlineQueryResults_id = #answerInlineQueryResults + 1
if type(value) == 'table' and type(value.type) == 'string' then
value.type = string.lower(value.type)
if value.type == 'gif' then
  answerInlineQueryResults[newAnswerInlineQueryResults_id] = {
TD = 'inputInlineQueryResultAnimatedGif',
id = value.id,
title = value.title,
thumbnail_url = value.thumbnail_url,
gif_url = value.gif_url,
gif_duration = value.gif_duration,
gif_width = value.gif_width,
gif_height = value.gif_height,
reply_markup = TD1function.replyMarkup{
type = 'inline',
data = value.reply_markup
},
input_message_content = TD1function.getInputMessage(value.input)
}
elseif value.type == 'mpeg4' then
  answerInlineQueryResults[newAnswerInlineQueryResults_id] = {
TD = 'inputInlineQueryResultAnimatedMpeg4',
id = value.id,
title = value.title,
thumbnail_url = value.thumbnail_url,
mpeg4_url = value.mpeg4_url,
mpeg4_duration = value.mpeg4_duration,
mpeg4_width = value.mpeg4_width,
mpeg4_height = value.mpeg4_height,
reply_markup = TD1function.replyMarkup{
type = 'inline',
data = value.reply_markup
},
input_message_content = TD1function.getInputMessage(value.input)
}
elseif value.type == 'article' then
  answerInlineQueryResults[newAnswerInlineQueryResults_id] = {
TD = 'inputInlineQueryResultArticle',
id = value.id,
url = value.url,
hide_url = value.hide_url,
title = value.title,
description = value.description,
thumbnail_url = value.thumbnail_url,
thumbnail_width = value.thumbnail_width,
thumbnail_height = value.thumbnail_height,
reply_markup = TD1function.replyMarkup{
type = 'inline',
data = value.reply_markup
},
input_message_content = TD1function.getInputMessage(value.input)
}
elseif value.type == 'audio' then
  answerInlineQueryResults[newAnswerInlineQueryResults_id] = {
TD = 'inputInlineQueryResultAudio',
id = value.id,
title = value.title,
performer = value.performer,
audio_url = value.audio_url,
audio_duration = value.audio_duration,
reply_markup = TD1function.replyMarkup{
type = 'inline',
data = value.reply_markup
},
input_message_content = TD1function.getInputMessage(value.input)
}
elseif value.type == 'contact' then
  answerInlineQueryResults[newAnswerInlineQueryResults_id] = {
TD = 'inputInlineQueryResultContact',
id = value.id,
contact = value.contact,
thumbnail_url = value.thumbnail_url,
thumbnail_width = value.thumbnail_width,
thumbnail_height = thumbnail_height.description,
reply_markup = TD1function.replyMarkup{
type = 'inline',
data = value.reply_markup
},
input_message_content = TD1function.getInputMessage(value.input)
}
elseif value.type == 'document' then
  answerInlineQueryResults[newAnswerInlineQueryResults_id] = {
TD = 'inputInlineQueryResultDocument',
id = value.id,
title = value.title,
description = value.description,
document_url = value.document_url,
mime_type = value.mime_type,
thumbnail_url = value.thumbnail_url,
thumbnail_width = value.thumbnail_width,
thumbnail_height = value.thumbnail_height,
reply_markup = TD1function.replyMarkup{
type = 'inline',
data = value.reply_markup
},
input_message_content = TD1function.getInputMessage(value.input)
}
elseif value.type == 'game' then
  answerInlineQueryResults[newAnswerInlineQueryResults_id] = {
TD = 'inputInlineQueryResultGame',
id = value.id,
game_short_name = value.game_short_name,
reply_markup = TD1function.replyMarkup{
type = 'inline',
data = value.reply_markup
},
input_message_content = TD1function.getInputMessage(value.input)
}
elseif value.type == 'location' then
  answerInlineQueryResults[newAnswerInlineQueryResults_id] = {
TD = 'inputInlineQueryResultLocation',
id = value.id,
location = value.location,
live_period = value.live_period,
title = value.title,
thumbnail_url = value.thumbnail_url,
thumbnail_width = value.thumbnail_width,
thumbnail_height = value.thumbnail_height,
reply_markup = TD1function.replyMarkup{
type = 'inline',
data = value.reply_markup
},
input_message_content = TD1function.getInputMessage(value.input)
}
elseif value.type == 'photo' then
  answerInlineQueryResults[newAnswerInlineQueryResults_id] = {
TD = 'inputInlineQueryResultPhoto',
id = value.id,
title = value.title,
description = value.description,
thumbnail_url = value.thumbnail_url,
photo_url = value.photo_url,
photo_width = value.photo_width,
photo_height = value.photo_height,
reply_markup = TD1function.replyMarkup{
type = 'inline',
data = value.reply_markup
},
input_message_content = TD1function.getInputMessage(value.input)
}
elseif value.type == 'sticker' then
  answerInlineQueryResults[newAnswerInlineQueryResults_id] = {
TD = 'inputInlineQueryResultSticker',
id = value.id,
thumbnail_url = value.thumbnail_url,
sticker_url = value.sticker_url,
sticker_width = value.sticker_width,
sticker_height = value.sticker_height,
photo_width = value.photo_width,
photo_height = value.photo_height,
reply_markup = TD1function.replyMarkup{
type = 'inline',
data = value.reply_markup
},
input_message_content = TD1function.getInputMessage(value.input)
}
elseif value.type == 'sticker' then
  answerInlineQueryResults[newAnswerInlineQueryResults_id] = {
TD = 'inputInlineQueryResultSticker',
id = value.id,
thumbnail_url = value.thumbnail_url,
sticker_url = value.sticker_url,
sticker_width = value.sticker_width,
sticker_height = value.sticker_height,
photo_width = value.photo_width,
photo_height = value.photo_height,
reply_markup = TD1function.replyMarkup{
type = 'inline',
data = value.reply_markup
},
input_message_content = TD1function.getInputMessage(value.input)
}
elseif value.type == 'video' then
  answerInlineQueryResults[newAnswerInlineQueryResults_id] = {
TD = 'inputInlineQueryResultVideo',
id = value.id,
title = value.title,
description = value.description,
thumbnail_url = value.thumbnail_url,
video_url = value.video_url,
mime_type = value.mime_type,
video_width = value.video_width,
video_height = value.video_height,
video_duration = value.video_duration,
reply_markup = TD1function.replyMarkup{
type = 'inline',
data = value.reply_markup
},
input_message_content = TD1function.getInputMessage(value.input)
}
elseif value.type == 'videonote' then
  answerInlineQueryResults[newAnswerInlineQueryResults_id] = {
TD = 'inputInlineQueryResultVoiceNote',
id = value.id,
title = value.title,
voice_note_url = value.voice_note_url,
voice_note_duration = value.voice_note_duration,
reply_markup = TD1function.replyMarkup{
type = 'inline',
data = value.reply_markup
},
input_message_content = TD1function.getInputMessage(value.input)
}
end
end
end
return TD2function.run_table{
TD = 'answerInlineQuery',
inline_query_id = inline_query_id,
next_offset = next_offset,
switch_pm_text = switch_pm_text,
switch_pm_parameter = switch_pm_parameter,
is_personal = is_personal,
cache_time = cache_time,
results = answerInlineQueryResults,
}
end
function TD.VERSION()
  print('login')
return true
end
function TD.run(main_def, filters)
if type(main_def) ~= 'function' then
TD2function.print_error('the run main_def must be a main function !')
os.exit(1)
  else
TD3function[0] = {}
TD3function[0].def = main_def
TD3function[0].filters = filters
end
  while TD.TdUpdate do
for timer_id, timer_data in pairs(TD4function) do
if os.time() >= timer_data.run_in then
  xpcall(timer_data.def, TD2function.print_error,timer_data.argv)
  table.remove(TD4function,timer_id)
end
end
local update = TD2function.change_table(client:receive(1))
if update then
if type(update) ~= 'table' then
goto finish
end
if TD.login(update) then
TD2function.sendcall(update)
end
end
::finish::
end
end
function TD.set_config(data)
TD.VERSION()
if not data.api_hash then
print('Please enter AP_HASH to call')
os.exit()
end
if not data.api_id then
print('Please enter API_ID to call')
os.exit()
end
if not data.session_name then
print('please use session_name in your script !')
os.exit()
end
TD.config.bytoken = data.bytoken or ""
TD.config.bytokens = data.bytokens or ""
TD.config.username = data.username or ""
if not data.token and not TD1function.exists('.TDinfo/'..data.session_name) then
io.write('Please enter Token or Phone to call')
local phone_token = io.read()
if phone_token:match('%d+:') then
TD.config.is_bot = true
TD.config.token = phone_token
else
TD.config.is_bot = false
TD.config.phone = phone_token
end
elseif data.token and not TD1function.exists('.TDinfo/'..data.session_name) then
TD.config.is_bot = true
TD.config.token = data.token
end
if not TD1function.exists('.TDinfo') then
os.execute('sudo mkdir .TDinfo')
end
TD.config.encryption_key = data.encryption_key or ''
TD.config.parameters = {
TD = 'setTdlibParameters',
use_message_database = data.use_message_database or true,
api_id = data.api_id,
api_hash = data.api_hash,
use_secret_chats = use_secret_chats or true,
system_language_code = data.language_code or 'en',
device_model = 'TD',
system_version = data.system_version or 'linux',
application_version = '1.0',
enable_storage_optimizer = data.enable_storage_optimizer or true,
use_pfs = data.use_pfs or true,
database_directory = '.TDinfo/'..data.session_name
}
return TD1function
end
function TD.login(state)
if state.name == 'version' and state.value and state.value.value then
elseif state.authorization_state and state.authorization_state.TD == 'error' and (state.authorization_state.message == 'PHONE_NUMBER_INVALID' or state.authorization_state.message == 'ACCESS_TOKEN_INVALID') then
if state.authorization_state.message == 'PHONE_NUMBER_INVALID' then
print('Phone Number invalid Error ?!')
else
print('Token Bot invalid Error ?!')
end
io.write('Please Use Token or Phone to call : ')
local phone_token = io.read()
if phone_token:match('%d+:') then
TD2function.send_tdlib{
TD = 'checkAuthenticationBotToken',
token = phone_token
}
else
TD2function.send_tdlib{
TD = 'setAuthenticationPhoneNumber',
phone_number = phone_token
}
end
elseif state.authorization_state and state.authorization_state.TD == 'error' and state.authorization_state.message == 'PHONE_CODE_INVALID' then
io.write('The Code : ')
local code = io.read()
TD2function.send_tdlib{
TD = 'checkAuthenticationCode',
code = code
}
elseif state.authorization_state and state.authorization_state.TD == 'error' and state.authorization_state.message == 'PASSWORD_HASH_INVALID' then
print('two-step is wrong !')
io.write('The Password : ')
local password = io.read()
TD2function.send_tdlib{
TD = 'checkAuthenticationPassword',
password = password
}
elseif state.TD == 'authorizationStateWaitTdlibParameters' or (state.authorization_state and state.authorization_state.TD == 'authorizationStateWaitTdlibParameters') then
TD2function.send_tdlib{
TD = 'setTdlibParameters',
use_message_database = TD.config.parameters.use_message_database,
api_id = TD.config.parameters.api_id,
api_hash = TD.config.parameters.api_hash,
use_secret_chats = TD.config.parameters.use_secret_chats,
system_language_code = TD.config.parameters.system_language_code,
device_model = TD.config.parameters.device_model,
system_version = TD.config.parameters.system_version,
application_version = TD.config.parameters.application_version,
enable_storage_optimizer = TD.config.parameters.enable_storage_optimizer,
use_pfs = TD.config.parameters.use_pfs,
database_directory = TD.config.parameters.database_directory,
}
elseif state.authorization_state and state.authorization_state.TD == 'authorizationStateWaitEncryptionKey' then
TD2function.send_tdlib{
TD = 'checkDatabaseEncryptionKey',
encryption_key = TD.config.encryption_key
}
elseif state.authorization_state and state.authorization_state.TD == 'authorizationStateWaitPhoneNumber' then
if TD.config.is_bot then
TD2function.send_tdlib{
TD = 'checkAuthenticationBotToken',
token = TD.config.token
}
else
TD2function.send_tdlib{
TD = 'setAuthenticationPhoneNumber',
phone_number = TD.config.phone
}
end
elseif state.authorization_state and state.authorization_state.TD == 'authorizationStateWaitCode' then
io.write('The Password : ')
local code = io.read()
TD2function.send_tdlib{
TD = 'checkAuthenticationCode',
code = code
}
elseif state.authorization_state and state.authorization_state.TD == 'authorizationStateWaitPassword' then
io.write('Password [ '..state.authorization_state.password_hint..' ] : ')
local password = io.read()
TD2function.send_tdlib{
TD = 'checkAuthenticationPassword',
password = password
}
elseif state.authorization_state and state.authorization_state.TD == 'authorizationStateWaitRegistration' then
io.write('The First name : ')
local first_name = io.read()
io.write('The Last name : ')
local last_name = io.read()
TD2function.send_tdlib{
TD = 'registerUser',
first_name = first_name,
last_name = last_name
}
elseif state.authorization_state and state.authorization_state.TD == 'authorizationStateReady' then
print("- تم اكمال المعلومات جارِ تشغيل البوت .")
elseif state.authorization_state and state.authorization_state.TD == 'authorizationStateClosed' then
print('authorizationStateClosed')
TD.TdUpdate = false
elseif state.TD == 'error' and state.message then
elseif not (state.TD and TD1function.in_array({'updateConnectionState', 'updateSelectedBackground', 'updateConnectionState', 'updateOption',}, state.TD)) then
return true
end
end
return TD